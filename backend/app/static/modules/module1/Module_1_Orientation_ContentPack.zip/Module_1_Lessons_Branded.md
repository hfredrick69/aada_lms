# Module 1 – Orientation & Professional Foundations
**Atlanta Academy of Dental Assisting**

![AADA Logo](assets/aada_logo_placeholder.png)

> **Theme:** Gold / Cream brand colors  
> **Estimated Time:** 40 hours (3 weeks)  
> **Delivery Mode:** Online + Live (1 Kick-off Session)

## 1. Welcome to AADA
[TTS: Female, American Neutral] Welcome to your Dental Assistant Certificate journey at AADA…

(H5P Activity: Welcome Carousel)

## 2. Professionalism & Ethics
[TTS] Explore the standards that define professional behavior in dental assisting.

(H5P Activity: Branching Scenario – Ethical Dilemmas)

## 3. HIPAA and OSHA Essentials
(TTS) Every dental assistant must understand patient privacy and workplace safety.

(H5P Activity: Interactive Video – HIPAA in Action)

## 4. Communication & Team Dynamics
(H5P Activity: Dialog Cards – Effective Phrases)

## 5. Using the LMS & Support Resources
Checklist: Upload photo | Test audio | Review policies | Post intro message

## 6. Summary and Assessment
Quiz (25 questions) + Signed Acknowledgment Form + Kick-off Q&A attendance.
